import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Home from "./page/Home";
import Movies from "./page/Movies";
import Tvseries from "./page/Tvseries";
import List from "./page/List";
import axios from "axios";

function App() {
  return (
    <BrowserRouter>
      <header>
        <div className="header_wrap">
          <div className="logo">
            <a href="/">YFLIX</a>
          </div>
          <ul className="gnb">
            <li>
              <a>
                <Link to="/">Home</Link>
              </a>
            </li>
            <li>
              <a>
                <Link to="/movies">Movies</Link>
              </a>
            </li>
            <li>
              <a>
                {" "}
                <Link to="/tvseries">TV series</Link>
              </a>
            </li>
          </ul>
        </div>
        <div className="page_head">
          <h2>Movies</h2>
        </div>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movies" element={<Movies />} />
          <Route path="/tvseries" element={<Tvseries />} />
        </Routes>
      </main>
      <footer>
        <div class="logo">
          <a href="/">YFLIX</a>
        </div>
        <div class="foot_menu">
          <ul className="list">
            <li>
              <a>Home</a>
            </li>
            <li>
              <a>Contact us</a>
            </li>
            <li>
              <a>Term of services</a>
            </li>
            <li>
              <a>About us</a>
            </li>
          </ul>
          <ul className="list">
            <li>
              <a>Live</a>
            </li>
            <li>
              <a>FAQ</a>
            </li>
            <li>
              <a>Premium</a>
            </li>
            <li>
              <a>Pravacy policy</a>
            </li>
          </ul>
          <ul className="list">
            <li>
              <a>You must watch</a>
            </li>
            <li>
              <a>Recent release</a>
            </li>
            <li>
              <a>Top IMDB</a>
            </li>
          </ul>
        </div>
      </footer>
    </BrowserRouter>
  );
}

export default App;
