import React, { useEffect, useState } from "react";
import axios from "axios";

export default function List() {
  const [movieDataP, setMovieDataP] = useState([]);
  const [movieDataT, setMovieDataT] = useState([]);
  const [movieDataU, setMovieDataU] = useState([]);
  const [searchQuery, setSearchQuery] = useState(""); // 검색어를 저장할 상태

  const dbData = axios.create({
    baseURL: "https://api.themoviedb.org/3",
    params: { api_key: "f89a6c1f22aca3858a4ae7aef10de967" },
  });

  useEffect(() => {
    dbData.get("/movie/popular").then((res) => {
      const moviePop = res.data;
      setMovieDataP(moviePop.results);
    });
    dbData.get("/movie/top_rated").then((res) => {
      const movieTop = res.data;
      setMovieDataT(movieTop.results);
    });

    dbData.get("/movie/upcoming").then((res) => {
      const movieUop = res.data;
      setMovieDataU(movieUop.results);
    });
  }, []);

  // 검색어를 기반으로 영화를 필터링하는 함수
  const filteredMovies = (movies) => {
    if (searchQuery === "") {
      return movies; // 검색어가 없을 때는 모든 영화 표시
    }
    return movies.filter((movie) =>
      movie.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  return (
    <>
      <div className="search-bar">
        <input
          type="text"
          placeholder="영화 검색..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button onClick={() => setSearchQuery("")}>search</button>
      </div>

      <section className="movie">
        <h2>인기 영화</h2>
        <ul>
          {filteredMovies(movieDataP).map((e) => (
            <li key={e.id}>
              <img
                src={`https://image.tmdb.org/t/p/w200${e.poster_path}`}
                alt={e.title}
              />
              <h3>{e.title}</h3>
            </li>
          ))}
        </ul>
      </section>

      <section className="movie">
        <h2>평점 높은 영화</h2>
        <ul>
          {filteredMovies(movieDataT).map((e) => (
            <li key={e.id}>
              <img
                src={`https://image.tmdb.org/t/p/w200${e.poster_path}`}
                alt={e.title}
              />
              <h3>{e.title}</h3>
            </li>
          ))}
        </ul>
      </section>

      <section className="movie">
        <h2>예정</h2>
        <ul>
          {filteredMovies(movieDataU).map((e) => (
            <li key={e.id}>
              <img
                src={`https://image.tmdb.org/t/p/w200${e.poster_path}`}
                alt={e.title}
              />
              <h3>{e.title}</h3>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
