import React from "react";

function Movies() {
  return <div>Movies</div>;
}

export default Movies;
